# Inferna IDE - Assets & Icons Package

Pacote completo de ativos visuais e ícones para a distribuição standalone Inferna IDE.

## Estrutura do Pacote:

### 1. Ícones do Aplicativo / Launcher (`/icons`)
- `inferna.png` (512x512) -> Ícone de alta definição para Linux Desktop (.desktop)
- `inferna.ico` (Multi-camada 16x16 até 256x256) -> Ícone de executável para Windows (.exe)
- `inferna_icon_<size>x<size>.png` -> Todas as resoluções padrão (16, 24, 32, 48, 64, 128, 256, 512)

### 2. Ícones Internos da IDE (`/icons`)
- `pluginIcon.svg` (80x80) -> Colocar em `src/main/resources/META-INF/pluginIcon.svg`
- `infernaDashboard.svg` (16x16) -> Colocar em `src/main/resources/icons/infernaDashboard.svg`
- `springBeanGutter.svg` (12x12) -> Colocar em `src/main/resources/icons/springBeanGutter.svg`

### 3. Splash Screen (`/splash`)
- `inferna_splash_640x400.png` -> Dimensão oficial da IntelliJ Platform (16:10)
- `inferna_splash_hi_res.png` -> Versão original em altíssima resolução sem barras de progresso
